@extends('layouts.master')
@section('content')

<div class="wrap">
	<div class="main">
		<h1><i class="fa fa-frown-o"></i></h1>
		<h1>ERROR 404</h1>
		<p>The page <span class="error">you are looking for could not be Found</span>.<br>
			<span class="error"><a href="/tran"><i class="fa fa-chevron-left"></i> Take Me Back Home</a></span>
		</p>

		


	</div>

</div>



</div>    
@stop




