@extends('layouts.master')
@section('content')

<div class="wrap">
	<div class="main">

		<h1>ERROR 500</h1>
		<p>Internal Server Error. <span class="error">Looks like Something just went wrong</span>.<br>
			<span class="error"><a href="/tran">Take Me Back Home</a></span>
		</p>

		


	</div>

</div>



</div>    
@stop




