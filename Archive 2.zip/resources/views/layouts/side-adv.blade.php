<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 hidden-xs">
  <div class="adv-banner">
   <img src="{{ URL::asset('assets/img/advert-banner1.svg') }}" />
  </div>
</div>  