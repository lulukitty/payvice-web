<tr>
    <td style='color: #fff; background-color: #00A4EF !important; font-size: 10px; font-weight: bold;' colspan='3' align='center'>&copy; Itex Integrated Services 2018 </td>
</tr>
<tr>
    <td style="text-align: center;">To stop receiving emails from this source, you can <a href="#">unsubscribe</a><br> | All rights reserved.
    </td>
</tr>
</table>
</center>	
</body>
</html>