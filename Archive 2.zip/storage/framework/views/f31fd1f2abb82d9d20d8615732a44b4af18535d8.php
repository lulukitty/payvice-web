<?php echo $__env->make('emails.layout.mailheader', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>   
<tr>
<td style='color: #000; background-color: #fff;' colspan='3' align='left'>
    <p>
        <?php echo e($Body); ?>

    </p>
    <p>
        <table>
            
            <tr>
                <td>Status</td><td> <?php echo e($data['status']); ?></td>
            </tr>
            <tr>
                <td>Message</td><td> <?php echo e($data['message']); ?></td>
            </tr>
            <tr>
                <td>Description</td><td> <?php echo e($data['description']); ?></td>
            </tr>
            <tr>
                <td>Date/Time Reported</td><td><?php echo e(date("jS \of F Y, h:i:s A")); ?></td>
            </tr>
            
        </table>
    </p>
</td>
</tr>
<?php echo $__env->make('emails.layout.mailfooter', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>   