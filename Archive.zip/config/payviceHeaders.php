<?php

return [
    'IIS_AUTH ' => 'IISYSGROUP c1e750cf89b05b0fc56eecf6fc25cce85e2bb8e0c46d7bfed463f6c6c89d4b8e',
    'IIS_SYSID' => 'ee2dadd1e684032929a2cea40d1b9a2453435da4f588c1ee88b1e76abb566c31'
];
